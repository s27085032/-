# 小雞生活管家（更新版）
這包是「可用 GitHub Actions 產生 APK」的專案檔。

## 更新 App（你手機就能做）
1) 把這個 zip 解壓後，上傳到你的 GitHub repo（建議覆蓋舊檔）
2) 去 Actions -> Build Android APK -> Run workflow
3) 跑完下載 Artifacts：chick-life-butler-apk -> 解壓得到 app-debug.apk
4) 先刪舊版再裝新版（若覆蓋安裝失敗）

## 這版新增
- App 名稱：小雞生活管家
- 圖示：小雞 icon（assets/icon.png，自動產生 Android icons）
- 佈景切換：晨光/夜色/搖滾
- 搖滾雞爪節拍（原創）：按「🥁搖滾」或點小雞解鎖音訊
- 右下角簽名：小雞（ChatGPT）

注意：背景音樂因手機限制，通常需要你按一次按鈕/小雞才能開始播放。
