# 小雞生活管家：手機打包 APK（不需要電腦）

這份專案已把你的「小雞生活管家 PWA」包進 Capacitor，並提供 GitHub Actions 一鍵產 APK。

## 你要準備
- 一個 GitHub 帳號（免費）
- 手機可上網（跑 Actions 用）

## 步驟（全部手機完成）
1) 在 GitHub 建立新 repository（例如：chick-butler）
   - 建議選「Public」（Actions 比較省事；不想公開也可用 Private）

2) 把這個 zip 解壓縮後的所有檔案，上傳到 repo 根目錄
   - 你應該會看到：www/、package.json、capacitor.config.json、.github/workflows/android-apk.yml

3) 到 GitHub 該 repo 的「Actions」
   - 找到 **Build Android APK**
   - 點 **Run workflow**

4) 等它跑完（會變成綠色 ✅）
   - 點進那次 run
   - 往下找 **Artifacts**
   - 下載 **chick-butler-apk**

5) 解壓縮後拿到 `app-debug.apk`
   - Android 安裝時如果被擋：
     設定 → 安全性/隱私 → 允許「安裝未知應用」
     （允許你下載 APK 的那個 App，例如 Chrome / GitHub）

## 更新版本
- 你之後若有改 www/ 裡的檔案（例如 UI/功能），上傳到 repo
- 再跑一次 Actions，就會產出新的 APK

## 資料存哪裡？
- 目前資料存在 App 的 WebView localStorage（跟你之前離線版一樣）
- 移機請用 App 內「匯出 JSON / 匯入 JSON」備份還原
